
import React, { useEffect, useState, Suspense } from "react";
import { Canvas } from "@react-three/fiber";
import { OrbitControls, useGLTF } from "@react-three/drei";
import { motion } from "framer-motion";

/*
Simple but practical 3D body loader:
- expects two model files in public/models/: male.glb and female.glb
- will load the selected model and apply non-destructive scaling to body parts
  (attempts to find named nodes; otherwise scales the whole model proportions)
- stores history locally (localStorage)
- easy to run (see README in zip)
*/

function useModel(path){
  const gltf = useGLTF(path, true);
  return gltf;
}

function ScalableModel({ gltf, measurements }){
  // measurements: {height, waist, hips, chest, sex}
  // Try to find named bones/meshes to scale. Common names vary, so we fallback to scaling root.
  const root = gltf.scene.clone();

  // Basic heuristic scaling factors relative to typical baseline (these baselines can be tuned)
  const baseline = {height: 175, waist: 80, hips: 95, chest: 92};
  const hScale = measurements.height / baseline.height;
  const waistScale = measurements.waist / baseline.waist;
  const hipsScale = measurements.hips / baseline.hips;
  const chestScale = measurements.chest / baseline.chest;

  // If model contains groups/meshes named with common words, scale them individually.
  const tryNames = (nodeName)=>{
    const node = root.getObjectByName(nodeName);
    if(node){
      return node;
    }
    // try case-insensitive search
    const found = root.children.find(c => c.name && c.name.toLowerCase().includes(nodeName.toLowerCase()));
    return found || null;
  };

  // Apply scales (non-destructive: scale local parts; if not found scale root)
  const chestNode = tryNames("Chest") || tryNames("Torso") || tryNames("Spine") || null;
  const waistNode = tryNames("Waist") || tryNames("Abdomen") || tryNames("Hips") || null;
  const hipsNode = tryNames("Hips") || tryNames("Pelvis") || null;

  if(chestNode){
    chestNode.scale.set(chestScale, hScale, chestScale);
  }
  if(waistNode){
    waistNode.scale.set(waistScale, hScale, waistScale);
  }
  if(hipsNode){
    hipsNode.scale.set(hipsScale, hScale, hipsScale);
  }
  // fallback: if no nodes found, scale root proportional to height and waist average
  if(!chestNode && !waistNode && !hipsNode){
    const avg = (hScale + ((waistScale+hipsScale+chestScale)/3))/2;
    root.scale.set(avg, avg, avg);
  }

  // Position slightly above ground
  root.position.y = -0.9 + (hScale-1)*0.9;

  return <primitive object={root} />;
}

export default function BodyProgressWebapp(){
  const [sex, setSex] = useState("male");
  const [age, setAge] = useState(28);
  const [height, setHeight] = useState(180);
  const [weight, setWeight] = useState(80);
  const [neck, setNeck] = useState(38);
  const [waist, setWaist] = useState(85);
  const [hips, setHips] = useState(98);
  const [sessionsPerWeek, setSessionsPerWeek] = useState(3);
  const [activity, setActivity] = useState("moderate");
  const [goal, setGoal] = useState("maintain");

  const [results, setResults] = useState(null);
  const [history, setHistory] = useState([]);
  const [selectedIndex, setSelectedIndex] = useState(null);

  // load models
  const male = useModel("/models/male.glb");
  const female = useModel("/models/female.glb");

  useEffect(()=>{
    const saved = localStorage.getItem("bp_history_v2");
    if(saved) setHistory(JSON.parse(saved));
  },[]);

  // Navy method body fat calc
  function calcBodyFatPercent({sex,height,neck,waist,hips}){
    const h = Number(height);
    const n = Number(neck);
    const w = Number(waist);
    const hp = Number(hips);
    if(sex==="male"){
      return 86.010 * Math.log10(w - n) - 70.041 * Math.log10(h) + 36.76;
    }else{
      return 163.205 * Math.log10(w + hp - n) - 97.684 * Math.log10(h) - 78.387;
    }
  }

  function calcBMR({sex,weight,height,age}){
    const w = Number(weight), h = Number(height), a = Number(age);
    if(sex==="male"){
      return 10*w + 6.25*h - 5*a + 5;
    }else{
      return 10*w + 6.25*h - 5*a - 161;
    }
  }

  function activityMultiplier(act){
    switch(act){
      case "sedentary": return 1.2;
      case "light": return 1.375;
      case "moderate": return 1.55;
      case "active": return 1.725;
      case "very": return 1.9;
      default: return 1.55;
    }
  }

  function computeAll(){
    const bf = calcBodyFatPercent({sex,height,neck,waist,hips});
    const bmr = calcBMR({sex,weight,height,age});
    const mult = activityMultiplier(activity);
    const maintenance = Math.round(bmr*mult);
    let target = maintenance;
    if(goal==="bulk") target = maintenance + 400;
    if(goal==="cut") target = maintenance - 400;
    const fatMassKg = (bf/100)*weight;
    const leanMassKg = Math.max(1, weight - fatMassKg);
    const proteinG = Math.round(2.0 * leanMassKg);
    const proteinCals = proteinG*4;
    const fatCals = Math.round(target * (goal==="bulk"?0.30: goal==="cut"?0.22:0.25));
    const fatG = Math.round(fatCals/9);
    const carbsG = Math.max(0, Math.round((target - proteinCals - fatCals)/4));

    const out = {
      bodyFatPercent: parseFloat(bf.toFixed(2)),
      bmr: Math.round(bmr),
      maintenance, target,
      leanMassKg: parseFloat(leanMassKg.toFixed(2)),
      fatMassKg: parseFloat(fatMassKg.toFixed(2)),
      macros: {proteinG, fatG, carbsG},
      timestamp: new Date().toISOString(),
      inputs: {sex,age,height,weight,neck,waist,hips,activity,sessionsPerWeek,goal}
    };
    setResults(out);
    const updated = [out, ...history].slice(0,200);
    setHistory(updated);
    localStorage.setItem("bp_history_v2", JSON.stringify(updated));
    setSelectedIndex(0);
  }

  function exportCSV(){
    const rows = history.map(h => {
      return [h.timestamp, h.inputs.height, h.inputs.weight, h.bodyFatPercent, h.leanMassKg, h.bmr, h.target].join(",");
    });
    const csv = ["timestamp,height_cm,weight_kg,bodyFatPct,leanMassKg,bmr,targetCalories", ...rows].join("\n");
    const blob = new Blob([csv], {type:"text/csv"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "body-progress.csv"; a.click(); URL.revokeObjectURL(url);
  }

  const currentModel = (results ? (results.inputs.sex==="female" ? female : male) : (sex==="female"?female:male));
  const displayMeasurements = {
    height: Number(selectedIndex!==null ? history[selectedIndex].inputs.height : height),
    waist: Number(selectedIndex!==null ? history[selectedIndex].inputs.waist : waist),
    hips: Number(selectedIndex!==null ? history[selectedIndex].inputs.hips : hips),
    chest: Math.round((Number(selectedIndex!==null ? history[selectedIndex].inputs.waist : waist) + Number(selectedIndex!==null ? history[selectedIndex].inputs.hips : hips))/2),
    sex: selectedIndex!==null ? history[selectedIndex].inputs.sex : sex
  };

  return (
    <div className="container">
      <div className="card" style={{display:"grid", gridTemplateColumns:"1fr 520px", gap:20}}>
        <div>
          <h2>Body Progress — jednoduché</h2>
          <div style={{marginTop:12}}>
            <div className="row">
              <div className="col">
                <label className="small">Pohlaví</label>
                <select className="input" value={sex} onChange={e=>setSex(e.target.value)}>
                  <option value="male">Muž</option>
                  <option value="female">Žena</option>
                </select>
              </div>
              <div className="col">
                <label className="small">Věk</label>
                <input className="input" type="number" value={age} onChange={e=>setAge(e.target.value)} />
              </div>
            </div>

            <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:12, marginTop:12}}>
              <div>
                <label className="small">Výška (cm)</label>
                <input className="input" type="number" value={height} onChange={e=>setHeight(e.target.value)} />
              </div>
              <div>
                <label className="small">Váha (kg)</label>
                <input className="input" type="number" value={weight} onChange={e=>setWeight(e.target.value)} />
              </div>
              <div>
                <label className="small">Obvod krku (cm)</label>
                <input className="input" type="number" value={neck} onChange={e=>setNeck(e.target.value)} />
              </div>
              <div>
                <label className="small">Obvod pasu (cm)</label>
                <input className="input" type="number" value={waist} onChange={e=>setWaist(e.target.value)} />
              </div>
              <div>
                <label className="small">Obvod boků (cm)</label>
                <input className="input" type="number" value={hips} onChange={e=>setHips(e.target.value)} />
              </div>
              <div>
                <label className="small">Cvičení (sessions/week)</label>
                <input className="input" type="number" value={sessionsPerWeek} onChange={e=>setSessionsPerWeek(e.target.value)} />
              </div>
            </div>

            <div style={{display:"flex", gap:8, marginTop:12}}>
              <select className="input" value={activity} onChange={e=>setActivity(e.target.value)}>
                <option value="sedentary">Sedentary</option>
                <option value="light">Light</option>
                <option value="moderate">Moderate</option>
                <option value="active">Active</option>
                <option value="very">Very</option>
              </select>
              <select className="input" value={goal} onChange={e=>setGoal(e.target.value)}>
                <option value="maintain">Udržet váhu</option>
                <option value="bulk">Nabrání svalů (bulk)</option>
                <option value="cut">Snížení váhy (cut)</option>
              </select>
            </div>

            <div style={{marginTop:12, display:"flex", gap:8}}>
              <button className="btn btn-primary" onClick={computeAll}>Spočítat</button>
              <button className="btn" onClick={()=>{localStorage.removeItem("bp_history_v2"); setHistory([]); setResults(null);}}>Reset</button>
              <button className="btn" onClick={exportCSV}>Export CSV</button>
            </div>

            {results && (
              <div style={{marginTop:14}} className="card">
                <div style={{display:"grid", gridTemplateColumns:"1fr 1fr"}}>
                  <div className="small">BMR</div><div className="small">{results.bmr} kcal/day</div>
                  <div className="small">Maintenance</div><div className="small">{results.maintenance} kcal/day</div>
                  <div className="small">Target</div><div className="small">{results.target} kcal/day</div>
                  <div className="small">Body fat %</div><div className="small">{results.bodyFatPercent}%</div>
                  <div className="small">Lean mass</div><div className="small">{results.leanMassKg} kg</div>
                </div>
                <div style={{marginTop:8}} className="small">
                  Macros: Protein {results.macros.proteinG} g · Fat {results.macros.fatG} g · Carbs {results.macros.carbsG} g
                </div>
              </div>
            )}
          </div>
        </div>

        <div>
          <h3 className="small">3D model — vizualizace</h3>
          <div className="canvas-wrap card" style={{marginTop:8}}>
            <Canvas camera={{position:[0,1.2,2.4], fov:40}}>
              <ambientLight intensity={0.8} />
              <directionalLight position={[5,5,5]} intensity={0.6} />
              <Suspense fallback={null}>
                {currentModel && <ScalableModel gltf={currentModel} measurements={displayMeasurements} />}
              </Suspense>
              <OrbitControls />
            </Canvas>
          </div>

          <div style={{marginTop:10}} className="card">
            <div style={{display:"flex", justifyContent:"space-between", alignItems:"center"}}>
              <div className="small">Historie (uloženo lokálně v prohlížeči)</div>
              <div className="small">Vyber záznam</div>
            </div>
            <div className="history" style={{marginTop:8}}>
              {history.length===0 && <div className="small">Žádná historie — udělej první výpočet.</div>}
              {history.map((h, i)=>(
                <div key={h.timestamp} style={{padding:8,borderRadius:8,background:selectedIndex===i?'#f1f5f9':'transparent',cursor:'pointer'}} onClick={()=>setSelectedIndex(i)}>
                  <div className="small">{new Date(h.timestamp).toLocaleString()}</div>
                  <div className="small">Váha: {h.inputs.weight} kg · BF%: {h.bodyFatPercent}% · Target: {h.target} kcal</div>
                </div>
              ))}
            </div>
            <div style={{display:"flex", gap:8, marginTop:8}}>
              <button className="btn" onClick={()=>{
                if(selectedIndex!==null){
                  const h = history[selectedIndex];
                  setHeight(h.inputs.height); setWeight(h.inputs.weight); setNeck(h.inputs.neck);
                  setWaist(h.inputs.waist); setHips(h.inputs.hips); setSex(h.inputs.sex); setAge(h.inputs.age);
                  setActivity(h.inputs.activity); setGoal(h.inputs.goal);
                }
              }}>Load selected</button>
              <button className="btn" onClick={()=>{
                if(selectedIndex!==null){
                  const updated = history.filter((_,idx)=>idx!==selectedIndex);
                  setHistory(updated); localStorage.setItem("bp_history_v2", JSON.stringify(updated)); setSelectedIndex(null);
                }
              }}>Delete selected</button>
            </div>
          </div>

          <div style={{marginTop:10}} className="small">
            <strong>Poznámka:</strong> Do složky <code>/public/models/</code> vlož <code>male.glb</code> a <code>female.glb</code>.
            Pokud modely neobsahují přesné názvy částí, kód provede aproximaci pomocí scale na celé modely.
          </div>
        </div>
      </div>
    </div>
  );
}
