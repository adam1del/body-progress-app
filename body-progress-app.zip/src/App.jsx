import React from 'react'
import BodyProgressWebapp from './BodyProgressWebapp'

export default function App(){
  return <BodyProgressWebapp />
}
