Place your 3D models here (GLB/GLTF).
- male.glb  -> male base model
- female.glb -> female base model

The loader will use these paths:
  /models/male.glb
  /models/female.glb

Use Mixamo, Sketchfab (downloadable) or ReadyPlayerMe to get free base models.
Prefer neutral, T-pose models without heavy clothing for best scaling results.
