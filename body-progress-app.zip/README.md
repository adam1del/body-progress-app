# Body Progress App (Vite + React + Three.js)

This is a minimal Vite React project that:
- Calculates BMR, maintenance/target calories, macros and body-fat using navy method
- Loads a **male.glb** and **female.glb** model from `public/models/`
- Applies approximate scaling to torso/waist/hips based on user measurements
- Stores history locally (localStorage)
- Ready to run and deploy (Vercel / Netlify)

## Quick start

1. Install dependencies
   ```
   npm install
   ```

2. Put your 3D models into `public/models/`:
   - `public/models/male.glb`
   - `public/models/female.glb`

3. Start dev server
   ```
   npm run dev
   ```

4. Open the address printed by Vite (usually http://localhost:5173)

## Deployment

- Deploy the repository to Vercel/Netlify — they detect Vite automatically.
- Build command: `npm run build`
- Output directory: `dist`

## Notes about realism

- This starter uses non-destructive scaling and heuristics. For truly realistic, anatomically-accurate morphing you'd want:
  - Models with **morph targets** (blendshapes) or a rigged skeleton with named bones.
  - A preprocessing step to create morph targets for chest/waist/hips.
  - Optionally a server-side renderer or snapshot exporter.

If you want, I can:
- Prepare example GLB models (I can't fetch them automatically, you must add them),
- Or create an extended version that supports morph targets if you supply a sample model.
